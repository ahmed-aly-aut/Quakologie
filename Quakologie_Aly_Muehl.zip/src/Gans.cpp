#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

#include "Gans.h"

/**
 * Funktion die die Gans schnattern l�sst
 */
void Gans::schnattern()
{
	cout << "Schnatter" << endl;
}
/**
 * Funktion die Gans zur�ckgibt
 */
string Gans::toString()
{
	return "Gans";
}
