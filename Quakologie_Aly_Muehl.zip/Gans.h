#ifndef GANS_H
#define GANS_H

#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

using namespace std;

class Gans {
public:
	void schnattern();

	string toString();

};
#endif
